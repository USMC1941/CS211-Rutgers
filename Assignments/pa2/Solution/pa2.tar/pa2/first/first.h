void readDict(FILE *dict_file);
void printResult();
void matchStr(char* str);